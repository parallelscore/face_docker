# face_docker

Instructions:

1. As a senior /mid level engineer, build a docker image that takes a youtube video and extracts uniques faces from any soccer video on youtube. Finally, make a pull request to this repository. 

2. Sample video on youtube: [here](https://www.youtube.com/watch?v=JriaiYZZhbY&amp;t=4s)


3. Attach your work in your name as a folder.


