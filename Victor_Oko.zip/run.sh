curl https://files.pythonhosted.org/packages/6c/49/75dda409b94841f01cbbc34114c9b67ec618265084e4d12d37ab838f4fd3/face_recognition-1.3.0.tar.gz > face_recognition-1.3.0.tar.gz
tar -xzvf face_recognition-1.3.0.tar.gz
cd face_recognition-1.3.0
python setup.py install
cd ..
pip install requirements.txt

