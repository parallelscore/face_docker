import os
import cv2
import logging
import numpy as np

logging.basicConfig(format='%(asctime)s [%(levelname)s] %(message)s', 
                    datefmt= '%m/%d/%Y %I:%M:%S %p', level=logging.DEBUG)
logger = logging.getLogger(__name__)


class ExtractFace:

    def __init__(self, video_path):

        self.video_path = video_path
        

    def face_detect(self):
        
        logger.info('Reading Video using OpenCV')
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        camera = cv2.VideoCapture(self.video_path)

        face_list = []
        while True:               #Running all images is computationally expensive using a CPU processor
            
            success, frame = camera.read()
            #frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            
            if success:

                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                
                faces = face_cascade.detectMultiScale(rgb, 1.3, 5)

                for i, (x,y,w,h) in enumerate(faces):
                    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    roi = rgb[y:y+h, x:x+w]
                    print(roi)

                    face_list.append(roi)

                    file_path = 'dataset/img%d.jpg' %(i,)
                    cv2.imwrite(file_path, roi)
        
            else:
                break
        
        logger.info("The camera has been released!")
        camera.release()

        array = np.array(face_list)
        

        return array        

extractor = ExtractFace('C:/Users/USER/Desktop/face_docker/video_data/BEST_FOOTBALL.mp4')
extractor.face_detect()
                    





    
        