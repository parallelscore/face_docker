# Face Detector-Extractor project
This is the repository contains the project submission for AI parallel score.

In this project a YouTube link was provided to extract the unique faces from a soccer video.

To achieve the objectives of this project a YouTube downloader was implemented.
Then updates were made to a repository that had performed a similar implementation.

Afterwards, the project was deployed using Docker to create an environment suitable for the deployment of the 
script as instructed.

## Instructions
* Build Docker image

    ``docker build -t ukachi/face-detect-extract .
    ``

or

    docker build -t <image_name> .
* Run Docker image and mount the current working directory of the codebase to see video output

    ``
    docker run -it -v %cd%:/app ukachi/face-detect-extract
    ``

* Alternatively you can run image in privileged bash mode to run the script 
    directly from the container by using

    ``docker run -it -v %cd%:/app  --privileged ukachi/face-detect-extract bash
    `` for Windows

    ``docker run -it -v 'pwd':/app  --privileged ukachi/face-detection bash
    `` for Linux
    
* You can then run the script from the container's bash by using the following command:

    ``python3 start.py``
    
    Note: This command is similar to the last line of the Dockerfile
    
### Important arg parse arguments to note
1. `--videos_dir` Path to the video to extract the faces (optional) 
`default="videos, type=str` 
    
2. `--output_path` This is the output path were the extracted faces would be saved,
`default=faces`, `type=str`

3. `--detect_interval` This can be used to determine the number of frames to carry out the face detection (optional), 
`default=1`, `type=int`

4. `--margin` This is used to add margin to the face (optional)
`default=10`, `type=int`

5. `--scale_rate`: This is used to scale down or enlarge the original video image (optional),
`default=0.7`, `type=float`

6. `--show_rate`: This is used to scale down or enlarge the images drawn by OpenCV (optional),
`type=float`, `default=1.0`

7. `--face_score_threshold`: This is used to specify the threshold of the extracted faces,range 0<x<=1 (optional)
`default=0.85`, `type=float`

8. `--youtube_link`: This is the URL used for downloading a YouTube video (optional)
`default=https://www.youtube.com/watch?v=JriaiYZZhbY&t=4s` (YouTube link for the project), `type=str`

9. `--face_landmarks`: This is used to specify whether to draw five face landmarks on extracted face or not (optional)
`action="store_true"`, `type=float`

10. `--no_display`: This is used to specify whether to display or not to display (optional)
`action="store_true"`, `type=float`

Because the video was too long and was maxing out the device of my RAM, 
the video had to be trimmed using these parameters

11. `--start`: This is used to specify the start of the video to trim (optional)
`default=0`, `type=int`

12. `--end`: This is used to specify the end of the video to trim (optional)
`default=15`, `type=int`

## References
1. [Face-Track-Detect-Extract](https://github.com/Linzaer/Face-Track-Detect-Extract)
2. [Docker image TensorFlow help](https://github.com/kkedich/docker-tensorflow-py3/blob/master/gpu.Dockerfile)
