import os

project_dir = os.path.dirname(os.path.abspath(__file__))
