from pytube import YouTube
from moviepy.video.io.ffmpeg_tools import ffmpeg_extract_subclip


def download_video(video_url):
    """
    This function is used to download a video from YouTube by using the URL
    :param video_url: (str)YouTube video url
    :return: Stores the youtube video with a specified file name
    """
    YouTube(video_url).streams.get_highest_resolution().download(filename="videos/downloaded_video.mp4")
    print("YouTube video downloaded")


def trim_video(start, end):
    """
    This function will trim the video and save it with the same filename
    :param start: (int) Start of the video in seconds
    :param end: (int) end of the video in seconds
    :return:
    """
    ffmpeg_extract_subclip("videos/downloaded_video.mp4", args.start, args.end,
                           targetname="videos/downloaded_video.mp4")

