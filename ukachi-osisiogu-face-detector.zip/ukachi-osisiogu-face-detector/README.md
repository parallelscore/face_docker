# Face Detector project
This is the repository contains the project submission for AI parallel score.

## Instructions
* Build Docker image

    ``docker build -t ukachi/face-detection .
    ``

or

    docker build -t <image_name> .
* Run Docker image and mount the current working directory of the codebase to see video output

    ``
    docker run -it -v %cd%:/app ukachi/face-detection
    ``

* Alternatively you can run image in privileged bash mode to run the script 
    directly from the container by using

    ``docker run -it -v %cd%:/app  --privileged ukachi/face-detection bash
    `` for Windows

    ``docker run -it -v 'pwd':/app  --privileged ukachi/face-detection bash
    `` for Linux
    
* You can then run the script from the container's bash by using the following command:

    ``python3 face_detector.py --test_device "cpu"``
    
    Note: This command is similar to the last line of the Dockerfile
    
### Important arg parse arguments to note
1. `--net_type` This can be used to choose the network architecture used for inference (optional) 
`RFB` (higher precision) or `slim` (faster)
`default="RFB, type=str` 
    
2. `--input_size` This can be used to define the network input size (optional),
options `128/160/320/480/640/1280`, `default=480`, `type=int`

3. `--threshold` This can be used to determine the prediction/score threshold (optional), 
`default=0.7`, `type=float`

4. `--candidate_size` The non-maximum suppression is a technique used in Object detection to 
filter predictions/proposals (optional)
`default=1000`, `type=int`

5. `--path`: This is used to specify the image path for image face detection use cases (optional),
`default=image_path`, `type=str`

6. `--test_device`: This is used to choose the type of device running the inference(optional),
`cuda:0` for GPU, `cpu` for CPU
`default=cuda:0`, `type=str`

7. `--video_path`: This is used to specify the video path for the video face detection use cases (optional)
`default=video_path`, `type=str`

8. `--youtube_link`: This is the URL used for downloading a YouTube video (optional)
`default=https://www.youtube.com/watch?v=JriaiYZZhbY&t=4s` (YouTube link for the project), `type=str`

Because the video was too long and was maxing out the device of my RAM, 
the video had to be trimmed using these parameters

9. `--start`: This is used to specify the start of the video to trim (optional)
`default=0`, `type=int`

10. `--end`: This is used to specify the end of the video to trim (optional)
`default=15`, `type=int`
